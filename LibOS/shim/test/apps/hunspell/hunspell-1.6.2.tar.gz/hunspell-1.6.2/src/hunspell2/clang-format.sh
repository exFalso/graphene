clang-format -style=file -i *.cxx *.hxx
