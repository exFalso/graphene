package testlist

import (
	"fmt"
	"testing"
)

func TestSimple(t *testing.T) {
	_ = fmt.Sprint("Test simple")
}
