package d

import _ "canonical/b"
