package p

func f() (x.y, z int) {
}
