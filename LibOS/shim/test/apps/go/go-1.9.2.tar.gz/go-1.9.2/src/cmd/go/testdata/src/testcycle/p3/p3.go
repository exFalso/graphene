package p3

func init() {
	println("p3 init")
}
