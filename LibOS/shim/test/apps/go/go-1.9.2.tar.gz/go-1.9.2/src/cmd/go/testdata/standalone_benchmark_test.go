package standalone_benchmark

import "testing"

func Benchmark(b *testing.B) {
}
