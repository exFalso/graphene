package subsub

import "fmt"

func Hello() {
	fmt.Println("subsub.Hello")
}
