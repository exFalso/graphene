package a

import _ "c"
