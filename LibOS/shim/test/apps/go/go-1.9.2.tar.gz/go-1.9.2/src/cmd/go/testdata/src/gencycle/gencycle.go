//go:generate echo hello world

package gencycle

import _ "gencycle"
