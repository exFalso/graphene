package p_test

import (
	. "cgocover4"
	"testing"
)

func TestF(t *testing.T) {
	F()
}
