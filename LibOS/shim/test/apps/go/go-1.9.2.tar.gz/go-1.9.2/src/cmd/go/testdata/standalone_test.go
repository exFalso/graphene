package standalone_test

import "testing"

func Test(t *testing.T) {
}
