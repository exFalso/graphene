package vend

import _ "r"
