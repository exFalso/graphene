package main

import (
	_ "dupload/p2"
	_ "p"
)

func main() {}
