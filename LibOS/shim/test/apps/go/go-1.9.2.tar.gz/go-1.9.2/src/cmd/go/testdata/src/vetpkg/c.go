// +build tagtest

package p

import "fmt"

func g() {
	fmt.Printf("%d", 3, 4)
}
