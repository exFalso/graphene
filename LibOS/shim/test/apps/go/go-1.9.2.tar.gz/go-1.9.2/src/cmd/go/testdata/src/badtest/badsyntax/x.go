package badsyntax
