package p1

import _ "testcycle/p2"

func init() {
	println("p1 init")
}
