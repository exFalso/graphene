package p

/*
// hi
*/
import "C"

func F() {}
