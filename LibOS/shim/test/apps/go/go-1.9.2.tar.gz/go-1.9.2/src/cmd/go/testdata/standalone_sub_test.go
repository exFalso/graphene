package standalone_sub_test

import "testing"

func Test(t *testing.T) {
	t.Run("Sub", func(t *testing.T) {})
}
