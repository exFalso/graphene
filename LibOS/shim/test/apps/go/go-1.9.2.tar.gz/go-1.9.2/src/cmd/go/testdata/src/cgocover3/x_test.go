package p_test

import (
	. "cgocover3"
	"testing"
)

func TestF(t *testing.T) {
	F()
}
