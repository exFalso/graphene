package badc
