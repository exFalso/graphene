package p3

import (
	"testing"

	_ "testcycle/p1"
)

func Test(t *testing.T) {
}
