package badexec

func init() {
	panic("badexec")
}
