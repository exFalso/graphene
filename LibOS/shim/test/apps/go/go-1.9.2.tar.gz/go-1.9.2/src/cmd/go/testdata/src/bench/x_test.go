package bench

import "testing"

func Benchmark(b *testing.B) {
}
