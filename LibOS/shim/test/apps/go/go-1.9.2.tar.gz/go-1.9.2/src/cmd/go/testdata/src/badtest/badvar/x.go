package badvar
