package p1

import "testing"

func Test(t *testing.T) {
}
